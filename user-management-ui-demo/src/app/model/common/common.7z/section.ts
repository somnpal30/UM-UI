import { Field } from './field';

export class Section {
  label:string;
  fields:Field[];
}
