export class Validation {
  name: string;
  validator: string;
  message: string;
}
