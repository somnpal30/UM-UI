import { Validation } from './validation';

export class Field {
  label: string;
  type: string;
  inputType :string;
  name: String;
  id :String;
  value:String;
  isEditable: boolean
  validations: Validation[];
}
