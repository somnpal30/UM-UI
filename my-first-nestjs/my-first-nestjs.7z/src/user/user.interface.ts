export interface User {
  
  id: string;
  name: string;
  age: number;
  gender: string;
  company: string;
  email: string;
  phone: string;
  address: string;

}

