import { Component, NgModule, OnInit } from '@angular/core';
import { Field } from '../../../model/common/field';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-date',
  template: `
    <label for="{{field.id}}">{{field.label}}</label>
    <br>
    <mat-form-field appearance="outline"  class="field-full-width">
      <input matInput [matDatepicker]="picker"  id="{{field.id}}">
      <mat-datepicker-toggle matSuffix [for]="picker">
       <!--   <mat-icon matDatepickerToggleIcon>arrow_drop_down</mat-icon>-->
      </mat-datepicker-toggle>
      <mat-datepicker #picker></mat-datepicker>
    </mat-form-field>
  `,
  styles: [
  ]
})

export class DateComponent implements OnInit {
  field: Field;
  group: FormGroup;
  constructor() { }

  ngOnInit(): void {
  }

}
