import { Component, OnInit } from '@angular/core';
import { Field } from '../../../model/common/field';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'text-input',
  template: `

    <!--  <div>
        <label for="{{field.id}}">{{field.label}}</label>
        <input type="{{field.type}}" class="form-control" name="{{field.name}}" id="{{field.id}}">
      </div>-->
   <div>
    <label for="{{field.id}}">{{field.label}}</label>
    <br>
    <mat-form-field appearance="outline" class="field-full-width" >
      <input matInput class="field-fixed-height" name="{{field.name}}" id="{{field.id}}" (blur)="validate()">
      <ng-container *ngFor="let validation of field.validations;" ngProjectAs="mat-error">
        <mat-error *ngIf="group.get(field.name).hasError(validation.name)">error</mat-error>
      </ng-container>
    </mat-form-field>
   </div>
    <!-- <mat-form-field appearance="outline">
       <input matInput name="{{field.name}}" id="{{field.id}}">
     </mat-form-field>-->
  `,
  styles: [],
})
export class TextInputComponent implements OnInit {
  field: Field;
  group: FormGroup;

  constructor() {
  }

  ngOnInit(): void {
  }

  validate = () => {
    console.log("***********" + this.group.get(this.field.name).hasError("required"))

  }

}
