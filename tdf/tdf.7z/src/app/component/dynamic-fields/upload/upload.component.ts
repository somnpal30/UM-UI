import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload',
  template: `
    <p>
      upload works!
    </p>
  `,
  styles: [
  ]
})
export class UploadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
