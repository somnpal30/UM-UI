import { Component, OnInit } from '@angular/core';
import { Field } from '../../../model/common/field';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'selectField',
  template: `
  <!--  <div class="form-group">
      <label>{{field.label}}</label>
      <select class="custom-select" name="{{field.name}}">
         <option *ngFor="let topic of field.options">{{topic}}</option>
      </select>
    </div>-->
  <mat-label>{{field.label}}</mat-label>
  <br>
  <mat-form-field  class="field-full-width margin-top" [formGroup]="group" appearance="outline">
    <mat-select [formControlName]="field.name" value="field.value">
      <mat-option *ngFor="let item of field.options" [value]="item">{{item}}</mat-option>
    </mat-select>
  </mat-form-field>
  `,
  styles: [
  ]
})
export class SelectComponent implements OnInit {
  field: Field;
  group: FormGroup;
  constructor() { }

  ngOnInit(): void {
    console.log(this.field )
  }

}
