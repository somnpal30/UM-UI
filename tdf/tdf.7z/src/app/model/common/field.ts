import { Validation } from './validation';

export class Field {
  label: string;
  type: string;
  inputType: string;
  name: string;
  id: string;
  value: string;
  isEditable: boolean;
  options: string[];
  validations: Validation[];
}
