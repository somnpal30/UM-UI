import { Section } from './section';

export class Panel {
  label:string;
  sections:Section[];
}
